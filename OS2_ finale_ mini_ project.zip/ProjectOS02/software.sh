#!/bin/bash

echo "Welcome to the software script!!"
echo " "
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

echo -e "\e[34m===============SOFTWARE FULL REPORT=================================\e[0m"
TIMESTAMP=$(date +%F_%H-%M)
echo -e "\e[32mDate : $TIMESTAMP\e[0m"

echo " "
echo " "

#OS name and version
echo "OS name : "
echo "$(cat /etc/os-release | grep "Ubuntu")"
echo "==================================================================="
echo " "
echo "OS version : " 
echo "$(cat /etc/os-release | grep "VERSION")"
echo "==================================================================="
echo " "
echo "Helpful URLs : "
echo "$(cat /etc/os-release | grep "URL")"
echo " "
echo "=================================================================="
echo " "
echo " "
echo "System information."
echo " "
echo "Machine architecture : $(uname -a | awk '{print $15 " , " $16}')"
echo "=================================================================="
echo " "
echo "CPU model name of the processor : $(cat /proc/cpuinfo | grep "model name" | cut -d ':' -f2 | head -1)"
echo "==================================================================="
echo " "
echo "System package architecture : $(dpkg --print-architecture | grep -E "amd64|arm64|i386")"
echo " "
echo "==================================================================="

echo "Logged-in users : "
echo "$(w | awk 'NR>1 {print $1}')"
echo "==================================================================="
echo " "

##t : TCP , u:UDP , l : listen , n : numeric
echo "Listening ports : "
echo "$(ss -tuln | grep LISTEN | awk '{print $5}' | cut -d':' -f2 | sort -n)"
echo "===================================================================="
echo " "

echo "==================================================================="
echo " "

echo " "

echo "kernel version using proc :"
echo "$(cat /proc/version | awk '{print $3}') "

echo " "

echo "kernal name version :"

echo " $(uname -sr)"

echo " "

echo "kernel info from system data "
echo "$( uname -a | grep -i linux )"

echo  "  "

echo " ========================================================================="


echo " "
echo "Installed packages "

echo "  " 

echo "list of  installed packages : "

echo "$(dpkg -l | head -10 )"

echo " "

echo " ============================================================================== "

echo " "
echo "Count installed packages :"

echo " $(dpkg -l | wc -l)"

echo " "

echo " =============================================================================="

echo " "
echo "specific installed package :"

echo " $( dpkg -l | grep firefox )"

echo " "

echo "================================================================================="

echo " "

echo "Installed packages name : "

echo " $(dpkg -l | awk '{print $2}' | head -10) "

echo " "

echo "============================================================================"

echo "  "

echo "Installed package version : "
echo " $( dpkg -l | awk '{print $2,$3}' | head -10)"

echo " "

echo " ============================================================================ "

echo " "

echo "Active processes "
echo " "


echo "Processes of the user : "
echo " $(ps aux | grep username )"

echo " "

echo "==============================================================================" 
echo " "

echo "Processes of the root : "
echo " $(ps aux | grep root | head -10) "

echo " "

echo "==========================================================================="

echo " "

echo "PRocess tree :"
echo " $(pstree | grep systemd)"
echo " "
echo "==========================================================================="

echo " "

echo -e "\e[34m==============================END===========================================\e[0m"