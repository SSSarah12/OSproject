[35mSystem Audit And Remote Monitoring Tool.[0m

[31mFeatures : [0m

-Hardware audit (CPU , RAM , disk , network ..)
-Software audit (OS info , kernel version , groups and users , Running users .. )
-Reporting system (short and full for hardware / short and full for software)
-Email transmission (via msmtp)
-Automation using cron jobs

[35m===============================================================================[0m

[31mRequirements:[0m
-Ubuntu environment
-Bash shell
Tools : lscpu , df , free , ps , msmtp , cron 

[35m=======================================================================[0m

[31mInstallation and Setup[0m
1/-Make scripts executable : chmod +x main.sh hardware.sh..

2/-Configure msmtp for email sending.
     For the email some configurations are needed : 
     Create ~/.msmtprc with your email details (example for Gmail):
           defaults
           auth on
           tls on
           tls_trust_file /etc/ssl/certs/ca-certificates.crt

           account gmail
           host smtp.gmail.com
           port 587
           from your_email@gmail.com
           user your_email@gmail.com
           passwordeval gpg -d ~/.gmail-password.gpg

        account default : gmail
Lastly to secure the file : chmod 600 ~/.msmtprc

3/-Ensure cron is running.

[35m========================================================================[0m
[31mUsage.[0m
./main.sh
Reports generated are under the directory reports.
[35m=========================================================================[0m
[34mTHE END[0m
