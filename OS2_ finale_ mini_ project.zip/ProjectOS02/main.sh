#!/bin/bash

#this is only a try
echo -e "\e[36m============System administrators and Cybersecurity analyst============================\e[0m"
echo "This program will contain informations about Hardware and software of this Ubuntu VMware"
echo "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"
echo "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"

LOG_DIR="./reports"
mkdir -p "$LOG_DIR"

HW_FULL="$LOG_DIR/hardware_full.txt"
HW_SHORT="$LOG_DIR/hardware_short.txt"
SW_FULL="$LOG_DIR/software_full.txt"
SW_SHORT="$LOG_DIR/software_short.txt"


res=1

until [ "$res" = "0" ]
do

  echo "-------------------------------------------------"
  echo "Please consider choosing a number of the list : "
  echo -e "\e[33m1.1).FUll hardware report.\e[0m"
  echo  -e "\e[33m1.2).Short hardware report.\e[0m"
  echo  -e "\e[33m2.1).Full software report.\e[0m"
  echo -e "\e[33m2.2).Short software report.\e[0m"
  echo -e "\e[33m3).Sending via email.\e[0m"
  echo -e "\e[33m4).Setup automation.\e[0m"
  echo -e "\e[31m0).Exit.\e[0m"
  echo "--------------------------------------------------"

  echo "Answer :  "
  read res


  case $res in
   
  1.1)
  
      ./hardware.sh 2>&1 | tee "$HW_FULL"
     echo "Hardware full report is now ready!!"
     ;;
   1.2)   
     ./hardwareShort.sh 2>&1 | tee "$HW_SHORT"
      echo "Hardware short report is now ready!!"
      ;;
    
   2.1)
      ./software.sh 2>&1 | tee  "$SW_FULL"
      echo "Software full report is now ready!!"
      ;;

   2.2)
      ./softwareShort.sh 2>&1 | tee "$SW_SHORT"
      echo "Software short report is now ready!!"
      ;;

   3)   
      echo "Sending via email."
      echo "Enter you email : "
      read RECIPIENT

      echo "choose report to send : "
      echo -e "\e[35m1 - hardware full\e[0m"
      echo -e "\e[35m2 - hardware short\e[0m"
      echo -e "\e[35m3 - software full\e[0m "
      echo -e "\e[35m4 - software short\e[0m"

      read choice

      case $choice in
      1)
         REPORT="$HW_FULL";;
      2)
         REPORT="$HW_SHORT";;
      3)
         REPORT="$SW_FULL" ;;
      4)
         REPORT="$SW_SHORT";;
      *)
         echo "Invalis choice"
         ;; 
      esac

      if [ -f "$REPORT" ]; then
         echo "System Audit Report attached."
         cat "$REPORT" | msmtp "$RECIPIENT"
         echo "Report sent to $RECIPIENT"
      else
         echo "Error: $REPORT does not exist. Please generate the report first."
      fi

      ;;

   4)
      echo "Choose the report to automate : "
      echo -e "\e[35m1)Hardware Full.\e[0m"
      echo -e "\e[35m2)Hardware Short.\e[0m"
      echo -e "\e[35m3)Software Full.\e[0m"
      echo -e "\e[35m4)Software Short.\e[0m"

      read CHOICE

      case $CHOICE in

      1)
        crontab -l 2>/dev/null | { cat; echo "0 4 * * * ~/ProjectOS02/hardware.sh > ~/ProjectOS02/reports/hardware_full.txt" ;} | crontab - ; echo "Hardware full report scheduled daily at 04:00 AM"
        ;;
      2)   
        crontab -l 2>/dev/null | { cat; echo "0 4 * * * ~/ProjectOS02/hardwareShort.sh > ~/ProjectOS02/reports/hardware_short.txt" ;} | crontab - ; echo "Hardware short report scheduled daily at 04:00 AM"
        ;;
      3)
        crontab -l 2>/dev/null | { cat; echo "0 4 * * * ~/ProjectOS02/software.sh > ~/ProjectOS02/reports/software_full.txt" ;} | crontab - ; echo "Software full report scheduled daily at 04:00 AM"
         ;;
      4)
        crontab -l 2>/dev/null | { cat; echo "0 4 * * * ~/ProjectOS02/softwareShort.sh > ~/ProjectOS02/reports/software_short.txt" ;} | crontab - ; echo "Software short report scheduled daily at 04:00 AM"
        ;;

   
      esac
   ;;

   0)
     echo "Exiting the script ..."
     ;;
  *)
      echo "Invalid Option"
      ;;
   esac
done

echo " "

echo -e "\e[34m============================END OF AUDIT======================================\e[0m"