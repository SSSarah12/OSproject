#!/bin/bash

echo  " "

echo -e "\e[34m====================HARDWARE SHORT REPORT=====================\e[0m"
echo " "
TIMESTAMP=$(date +%F_%H-%M)
echo -e "\e[32mdate : $TIMESTAMP\e[0m"
echo " " 
echo -e "\e[32mHostname : $(hostname)\e[0m"
echo " " 
echo -e "\e[32mCPU: \e[0m"
echo " $(lscpu | grep -i Model )"
echo " "
echo -e "\e[32mMemory : \e[0m"
echo "$(free -h | grep Mem )"
echo " "
echo -e "\e[32mDisk usage : \e[0m"
echo "$(df -h | grep "^/dev") "
echo " "

echo "==============================================================="

echo -e "\e[34m=========================END===================================[0m"