#!/bin/bash

echo "Welcome to the hardware script!!"
echo "It will show detailed information but very precise"

echo "++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo ""
echo ""


echo -e "\e[34m===============HARDWARE FULL REPORT=================================\e[0m"
TIMESTAMP=$(date +%F_%H-%M)
echo -e "\e[32mDate : $TIMESTAMP\e[0m"

echo " "
echo " "
echo -e "\e[32mMEMORY INFORMATION\e[0m"
echo " "
echo " "
#1 show only total memory
total=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
echo  "Total memory : $total KB"
echo "========================================================="

echo ""


#2 show memory pressure Abialble vs used
pressure=$(free -m | awk 'NR==2 {printf "Used: %dMB\nAbailable: %dMB\n" , $3 , $7 }')
echo "Memory presseure (Avialable vs used): "
echo " $pressure "
echo "========================================================="
echo " "

#3 show inactive memory
inactive=$(grep -w Inactive /proc/meminfo)
echo "Inactive memory : "
echo "$inactive"
echo "========================================================="
echo " "

#4 show active memory
active=$(grep -w Active /proc/meminfo)
echo "Active memory : "
echo "$active"
echo "=========================================================="

#5 show memory in MB only
MB=$(grep MemTotal /proc/meminfo | awk '{print $2/1024 " MB" }')
echo "Memory in MB : $MB"
echo "=========================================================="
echo " "

#6 show used memory percentage
echo "Used memory percentage : $(free | grep Mem | awk '{printf("%.2f%%\n" , $3/$2 * 100)}')"
echo "============================================================"
echo " "

#7 show only process name and memory
echo "Process name and memory : "
echo " $(ps aux | sort -nrk 4 | head -5 | awk '{print $1 , $4 "%"}')"
echo "============================================================"
echo " "

#8 show Top 5 memory processes
echo "Top 5 memory processes : "
echo " $(ps aux | sort -nrk 4 | head -5)"
echo "============================================================"
echo " "


#9 show swap usage only 
echo "Swap usage only : "
echo " $(free | grep Swap | awk '{print $3 " MB used"}')"
echo "============================================================="
echo " "

#10 counting NUmber of Running processes
echo "The number of running processes : $(ps aux | wc -l)"
echo "=============================================================="
echo " "

#11 show process Using more than 5% memory
echo " "
echo "Processes using more than 5% memory : "
echo " $(ps aux | awk '$4 > 5 {print $11 , $4 "%"}')"
echo "=============================================================="
echo " "

#12 Show cached memory only : 
echo "Cached memory : $(grep ^Cached /proc/meminfo | awk '{print $2/1024 " MB"}')"
echo "============================================================="
echo " "

#13 Show top 10 processes sorted by real memory (rss)
echo "Show top 10 peocesses sorted by real memory : "
echo " $(ps -eo pid,comm,rss --sort=-rss | head )"
echo "============================================================="
echo " "

#14 Find processes using more than 100 MB
echo "processes using more than 100 MB :"
echo " $(ps -eo pid,comm,rss | awk '$3 > 102400 { printf "%s %s %.2f MB\n" , $1 , $2 , $3/1024}')"
echo "================================================================"
echo " "

#15 count how many processes use more than 1% RAM
echo "The number of processes using more than 1% RAM :  $(ps aux | awk '$4 > 1 {count++} END {print count}')"
echo "==============================================================="
echo " " 

#Detect if memory usage is above 80%

echo "Detecting is memory usage is above 80% in /dev/sda1"
#start the storage  check process
echo "{{{{{{{{{{}}}}}}}}}}"

echo "Start the storage check process"

#redirect all output to the storage_report.txt file in the
#exec >> ~/ProjectOS02/storage_report.txt


#define the partition to check
part=/dev/sda1

#iterate over the defined partition

for i in $part
do 
  
  checkper=$(df -h "$i" | awk  ' NR==2 {print $5}' | sed 's/%//g')
  if [[ $checkper -ge 95 && $checkper -le 100 ]] 
    then
    echo "ALERT: $i is $checkper% full!! Suggest immediate action.."
  elif [[ $checkper -ge 50  &&  $checkper -lt 95 ]] 
    then
    echo "CAUTION: $i is $checkper% full! COnsider freeing up some space..."
  elif [[ $checkper -lt 50 ]]
    then
    echo "$i is $checkper% full . No action required."
  else
    echo "Encountered an error . Status code."
    exit 3
  fi
done

echo "Storage check process is completed"
echo "===================================================================="
echo " "
echo " "

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo ""
echo ""
echo -e "\e[32mDISK INFORMATION\e[0m"
echo " "
echo " "

#show disk usage (only root partition)
echo "Disk partition for the root is : "
echo " $(df -h | grep "/$")"
echo "====================================================================="
echo " "


#show disk usage (execpt root )
echo "Disk usage : "
echo " $(df -h | grep tmpfs)"
echo "======================================================================"
echo " "

#show only usage percentage columns
echo "Usage percentage : "
echo " $(df -h | awk 'NR>1 {print $5}')"
echo "======================================================================"
echo " " 

#show top 10 largest files in the system
echo "Largest 10 files : "
echo "Please wait a little ..."
echo " $(du -ah / 2>/dev/null | sort -rh | head -10)"
echo "======================================================================="
echo " "

#show largest directories in /home
echo "Largest directories in /home : "
echo " $(du -h /home 2>/dev/null | sort -rh | head -10 )"
echo "========================================================================"
echo " "

#find files larger than 100MB
echo "Files larger than 100MB : "
echo " $(find / -type f -size +100M 2>/dev/null)"
echo "========================================================================"
echo " "

#show block devices and file systems
echo "Block devices and file systems : "
echo " $(lsblk -f | column -t)"
echo "========================================================================="
echo " "

#show olny physical disks
echo "Physical disks : "
echo " $(lsblk | grep disk)"
echo "========================================================================="
echo " "

#show inode usage 
echo "Inode usage : "
echo " $(df -i)"
echo "========================================================================="
echo " "

echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo " "
echo " "
echo -e "\e[32mNETWORK INTERFACES\e[0m"
echo " "
echo " "

#list all network interfaces
echo "ALl network interfaces : "
echo " $(ip a | grep "^[0-9]")"
echo "=========================================================================="
echo " "

#ip link " network device configuration "

#active interfaces have UP in their state so we search for it
echo "Active network interfaces : "
echo " $(ip link show | grep "state UP")"
echo "==========================================================================="
echo " "


#ip : is the modern replacement for ifconfig
#link show lists all  network interfaces
#-o : one line output
echo "Interfaces names : "
echo " $(ip -o link show | awk -F':' '{print $2}')"
echo "==========================================================================="
echo " "

#Only ip addresses
echo "Interfaces's ip addresses : "
echo " $(ip -4 addr | awk '/inet / {print $NF , $2}')"
echo "==========================================================================="
echo " "

#mac 
echo "Mac address of the interface enp0s3 : $(ip link | grep link/ether | awk '{print $2}')"
echo "============================================================================"
echo " "

#in this statistics we are gonna have only RX and TX statistics lines
echo "Network interfaces statistics : "
echo " $(ip -s link | grep -E "^[0-9] |RX|TX")"
echo "============================================================================"
#RX : received , mcast : multicast
#TX : transmitted traffic , carrier : sense errores , collsns : collisions detected
echo " "

#default gateway is via enp0s3
echo "Dfault gateway is : $(ip route | grep default | awk '{print $3}')"
echo "============================================================================"
echo " "

#DNS 
echo "DNS server : $(cat /etc/resolv.conf | grep nameserver)"
echo "============================================================================"
echo " "

#ss : used to dump sockets statistics
echo "Listening network parts : "
echo "$(ss -tuln | grep LISTEN)"
echo "============================================================================"

echo " "
echo " "
echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo ""
echo ""

echo -e "\e[32mUSB DEVICES\e[0m"

#show only usb devices
echo "USB devices : "
echo "$(lsusb | cat)"
echo "============================================================================"
echo " "

#number
echo "The number of USB devices : $(lsusb | wc -l)"
echo "============================================================================"
echo " "

#vendor is .....
echo "Vendor information of USB devices : "
echo "$(lsusb | cut -d' ' -f6)"
echo "============================================================================="
echo " "

#show only bus numbers to identify devices positions
echo "Bus numbers (positions) : "
echo "$(lsusb | nl | awk '{print $2 ":" $1}')"
echo "============================================================================="
echo " "

#from /sys
echo "USB devices from /sys : "
echo " $(ls /sys/bus/usb/devices | grep usb)"
echo "============================================================================="
echo " "


#datailed information about USB
echo "Dtails about USB devices : "
echo "$(udevadm info --export-db | grep -i usb | head -10)"
echo "=============================================================================="
echo " "



echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo " "
echo "" 
echo -e "\e[32mCPU\e[0m"
echo " "


echo " Show cpu model only : "
echo " $(lscpu | grep -i Model ) "

echo " ==================================================================="

echo " Counting logical cpus : "
echo " $(cat /proc/cpuinfo | grep -c "^ processo ")"


echo " ======================================================================="

echo "Cores per socket : "
echo " $(cat /proc/cpuinfo | grep "cpu cores" | uniq )"


echo " ======================================================================="

echo "Threads per core : "
echo " $(lscpu | grep -i thread ) "


echo "======================================================================== "

echo "Cache size :"
echo "$(cat /proc/cpuinfo | grep "cache size")"


echo " ======================================================================="

echo "The architecture : "
echo " $(lscpu | grep -i "architecture")"


echo " ======================================================================="

echo "Cpu flags : "
echo "$(cat /proc/cpuinfo | grep "flags" )"


echo "======================================================================== "

echo "Cpu sockets :"
echo "$(lscpu | grep  "Socket(s)")"


echo " ========================================================================= "

echo "Numa nodes: "
echo "$(lscpu | grep NUMA)"


echo " ========================================================================="


echo "Bogomips : " 
echo " $(cat /proc/cpuinfo | grep "bogomips" | uniq)"


echo "======================================================================== "


echo "Cpu stepping and revision : "
echo "$(cat /proc/cpuinfo | grep "stepping" )"


echo " ========================================================================="

echo " "

echo "Cpu cache : "
echo "$(lscpu | grep -i cache)"

echo " "


echo " ========================================================================"

echo "  "

echo "Cpu topology"
echo "$(lscpu | grep -i "topology")"

echo " "

echo "========================================================================="
 
echo "   "

echo "Microcode vesion "
echo "$(cat /proc/cpuinfo | grep -i "microcode" \ uniq)"

echo "  "

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

echo "  "
echo "" 

echo -e "\e[32mGPU\e[0m"

echo "  "

echo "Disply the gpu (vga controller) "

echo " $(lspci | grep -i vga) "

echo "   "

echo "======================================================================="

echo "  "


echo "Display gpu related devices : "
echo " $(lspci | grep -i display) "

echo "  "

echo "======================================================================"

echo "  "
echo " Display 3d graphics controller :"

echo " $(lspci | grep -i "3d")"

echo "  "

echo "======================================================================="

 echo "  "

echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

echo ""
echo ""

echo -e "\e[32mMAC AND IP ADDRESS\e[0m"

echo " "

echo "Show all ip addresses : "

echo " $(ip add) "

echo " "

echo "======================================================================="

echo " "

echo "====================================================================="

echo  " "
echo "Ip address of the machine "
echo " $( hostname -I )"
echo " "

echo "====================================================================="

echo " "

echo "Mac address "
echo " $(ip link )"
 echo " "

echo "========================================================================"

echo " " 

echo "Display mac adderss : "
echo "  $( ifconfig )"

echo " "

echo " ======================================================================="
echo ""

echo "Show mac table : "
echo "$(arp -a) "

echo " "

echo "======================================================================"

echo " "
echo "shows arp cache : "
echo " $(ip neigh)"
echo " "


echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"

echo "  "
echo -e "\e[32mMOTHERBOARD INFORMATION\e[0m"

echo " "

echo " board : "
echo " $(cat /sys/class/dmi/id/board_vendor)"


echo " "

echo " ================================================================================"

echo " "

echo " product : "

echo " $( cat /sys/class/dmi/id/product_name)"

echo " "

echo "=================================================================================="

echo " "

echo "bios:"

echo "$( cat /sys/class/dmi/id/bios_vendor) "

echo "  "

echo "================================================================================="
echo " "

echo -e "\e[34m===============================END===============================================\e[0m"