#!/bin/bash

exec > README.txt


echo -e "\e[35mSystem Audit And Remote Monitoring Tool.\e[0m"

echo ""

echo -e "\e[31mFeatures : \e[0m"

echo ""

echo "-Hardware audit (CPU , RAM , disk , network ..)"
echo "-Software audit (OS info , kernel version , groups and users , Running users .. )"
echo "-Reporting system (short and full for hardware / short and full for software)"
echo "-Email transmission (via msmtp)"
echo "-Automation using cron jobs"

echo ""

echo -e "\e[35m===============================================================================\e[0m"

echo ""

echo -e "\e[31mRequirements:\e[0m"
echo "-Ubuntu environment"
echo "-Bash shell"
echo "Tools : lscpu , df , free , ps , msmtp , cron "

echo ""

echo -e "\e[35m=======================================================================\e[0m"

echo ""

echo -e "\e[31mInstallation and Setup\e[0m"

echo "1/-Make scripts executable : chmod +x main.sh hardware.sh.."
echo ""
echo "2/-Configure msmtp for email sending."
echo "     For the email some configurations are needed : "
echo "     Create ~/.msmtprc with your email details (example for Gmail):
           defaults
           auth on
           tls on
           tls_trust_file /etc/ssl/certs/ca-certificates.crt

           account gmail
           host smtp.gmail.com
           port 587
           from your_email@gmail.com
           user your_email@gmail.com
           passwordeval gpg -d ~/.gmail-password.gpg

        account default : gmail" 
echo "Lastly to secure the file : chmod 600 ~/.msmtprc"
echo ""
echo "3/-Ensure cron is running."

echo ""
echo -e "\e[35m========================================================================\e[0m"

echo -e "\e[31mUsage.\e[0m"

echo "./main.sh"
echo "Reports generated are under the directory reports."

echo -e "\e[35m=========================================================================\e[0m"

echo -e "\e[34mTHE END\e[0m"
